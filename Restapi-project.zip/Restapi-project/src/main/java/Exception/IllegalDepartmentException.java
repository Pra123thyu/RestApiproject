package Exception;

public class IllegalDepartmentException extends RuntimeException {
     public IllegalDepartmentException(String message)
     {
     super(message);
}
}
