package com.sathya.restapis.Controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.sathya.restapis.Models.APIErrorResponse;

import Exception.EmployeeNotFoundException;
import Exception.IllegalDepartmentException;
@RestControllerAdvice
public class EmployeeControllerAdvice {
	@ExceptionHandler(EmployeeNotFoundException.class)
	public ResponseEntity<APIErrorResponse>handleNotFound(EmployeeNotFoundException ex)
	{
		APIErrorResponse apiErrorResponse=new APIErrorResponse();
		apiErrorResponse.setStatusCode(HttpStatus.NOT_FOUND.value());
		apiErrorResponse.setMessage(ex.getMessage());
		apiErrorResponse.setDateTime(LocalDateTime.now());
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				             .header("error info","the employee not found")
				             .body(apiErrorResponse);
	}
	
@ExceptionHandler(IllegalDepartmentException.class)
   public  ResponseEntity<APIErrorResponse>handleIllegalDept(IllegalDepartmentException ex)
   {
	APIErrorResponse apiErrorResponse=new APIErrorResponse();
	apiErrorResponse.setStatusCode(HttpStatus.BAD_REQUEST.value());
	apiErrorResponse.setMessage(ex.getMessage());
	apiErrorResponse.setDateTime(LocalDateTime.now());
	
	return ResponseEntity.status(HttpStatus.BAD_REQUEST)
			             .header("error info","dept not found")
			             .body(apiErrorResponse);
   }
    @ExceptionHandler(MethodArgumentNotValidException.class)
       public ResponseEntity<Map<String,String>>
    handleValidationException(MethodArgumentNotValidException ex)
    {
    	Map<String,String>errors = new HashMap<>();
    	// collect field errors
    	ex.getBindingResult().getAllErrors().forEach(error->
    	{
    		String fieldName=((FieldError)error).getField();
    		String message=error.getDefaultMessage();
    		errors.put(fieldName,message);
    		
    	});
    	return new ResponseEntity<>(errors,HttpStatus.BAD_REQUEST);
    	}
}









