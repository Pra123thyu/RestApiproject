package com.sathya.restapis.Service;

import java.io.FileNotFoundException;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.sathya.restapis.Models.Employee;
import com.sathya.restapis.Repository.EmployeeRepository;

import Exception.EmployeeNotFoundException;
import Exception.IllegalDepartmentException;
import io.swagger.v3.oas.annotations.parameters.RequestBody;

@Service

public class EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	//to save the employee details
	public Employee saveEmployeeData(Employee employee) {
		// TODO Auto-generated method stub
		//  Validate department (Hr, Developer, Tester)
        String dept = employee.getDept();
        if (!(dept.equals("Hr") || dept.equals("Developer") || dept.equals("Tester"))) {
            throw new IllegalDepartmentException("Dept is invalid");
        }

        //  Department should start with a capital letter
        if (!Character.isUpperCase(dept.charAt(0))) {
            throw new IllegalDepartmentException("Department should start with a capital letter");
        }

        //  Validate gender (Male / Female / M / F)
        String gender = employee.getGender();
        if (!(gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female")
                || gender.equalsIgnoreCase("M") || gender.equalsIgnoreCase("F"))) {
            throw new IllegalDepartmentException("Gender is invalid");
        }
        
        double salary = employee.getSalary();
        if (salary > 30000) {
            double bonus = salary * 0.10;
            salary += bonus;
        }
        double pf = salary* 0.05;
        double tax = salary* 0.30;
        double finalSalary = salary- (pf + tax);

        employee.setSalary(finalSalary);
        employee.setPf(pf);
        employee.setTax(tax);

	        return employeeRepository.save(employee);
	}
	
	
	//Get the all Employee details
	public List<Employee> getEmployee()
	{
			List<Employee>employees=employeeRepository.findAll();
		return employees;
	}

	
    //get the employee details by specific id
	public Employee getEmployeebyId(Long id) {
		Optional<Employee>optionalemp=employeeRepository.findById(id);
		return optionalemp.orElseThrow(()->new EmployeeNotFoundException("The emp with"+id+"not available"));
	}
	
	//delete the employee details by specific id
	public void deleteEmployeeId(Long id){
		if(employeeRepository.existsById(id))
		{
			employeeRepository.deleteById(id);
		}
		else {
			throw new RuntimeException("No data Found");
		}
	}


	public Employee UpdateEmployeeById(Long id, Employee updateEmployeeDetails) {
		Optional<Employee>optionalEmployee=employeeRepository.findById(id);
	      Employee existing=optionalEmployee.orElseThrow(()->new EmployeeNotFoundException("Emp not found by id"+id));
	      
	      //Update the existing employee with new updated details
	    existing.setName(updateEmployeeDetails.getName());
	    existing.setGender(updateEmployeeDetails.getGender());
	    existing.setSalary(updateEmployeeDetails.getSalary());
	    existing.setDept(updateEmployeeDetails.getDept());
	    
	    //save the employee details
	    return employeeRepository.save(existing);
	}


	public Employee UpdateSpecificEmployeeById(Long id,Map<String,Object> UpdateSpecificDetails) {
		Optional<Employee>optionalEmployee=employeeRepository.findById(id);
	      Employee existingEmp=optionalEmployee.orElseThrow(()->new EmployeeNotFoundException("Emp not found by id"+id));
	     
	      UpdateSpecificDetails.forEach((k,v) ->{
	                switch(k){
	                case "name":existingEmp.setName((String)v);
	                break;
	                case "Gender":existingEmp.setGender((String)v);
	                break;
	                case "salary":existingEmp.setSalary((Double)v);
	                break;
	                case "Dept":existingEmp.setDept((String)v);
	                break;
	               
	                default:
	                    throw new IllegalArgumentException("Field not found: " + k);
	                }
	                
	                    });
		    return employeeRepository.save(existingEmp );
}


	public List<Employee> SaveAllEmployees(List<Employee> employees) {
		List<Employee> CreatedEmployees=employeeRepository.saveAll(employees);
		return CreatedEmployees;
	}


	public Long getEmployeecount() {
		Long count=employeeRepository.count();
		return count;
	}


	public void deleteAllEmployees() {
		  employeeRepository.deleteAll();		
	}


	public Employee getEmployeebyEmail(String email) {
		Optional<Employee>optionalemp=employeeRepository.findByEmail(email);
		return optionalemp.orElseThrow(()->new EmployeeNotFoundException("The emp with"+email+"not available"));
	}


	public List<Employee> getEmployeebyGender(String gender) {
		List<Employee> employees=employeeRepository.findByGender(gender);
		return employees; 
	
	}


	public List<Employee> getEmployeebyDeptAndGender(String dept,String gender) {
		List<Employee> employees=employeeRepository.findByDeptAndGender(dept,gender);
		return employees; 
	
	}


	public List<Employee> getEmployeebySalaryGreaterThan(double minsalary) {
		List<Employee> employees=employeeRepository.findBySalaryGreaterThan(minsalary);
		return employees; 
	}


	public List<Employee> getEmployeebySalaryBetween(double minsalary, double maxsalary) {
		List<Employee> employees=employeeRepository.findBySalaryBetween(minsalary,maxsalary);
		return employees;
	}
	
	
	
}
	
	
	
	
	
	

