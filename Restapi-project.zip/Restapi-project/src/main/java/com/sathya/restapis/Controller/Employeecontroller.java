 package com.sathya.restapis.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sathya.restapis.Models.Employee;
import com.sathya.restapis.Service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/vi/employees")
public class Employeecontroller {

	@Autowired
	EmployeeService employeeservice;
	
	
	/*@GetMapping("/greet")
	public String greeting()
	{
		return "Welcome to REST Apis....";
		
	}*/

public static final Logger logger=LoggerFactory.getLogger(Employeecontroller.class);



   //     @PostMapping("/save")
     //public ResponseEntity<Employee> SaveEmployee(@RequestBody @Valid Employee employee)
    //{
      //  logger.trace("It is used to save the data of the employee ");
	    // Employee SavedEmployee=employeeservice.saveEmployeeData(employee);
	    // return ResponseEntity.status(HttpStatus.CREATED)
	    	//.header("info","data saved successfully")
	    	//.body(SavedEmployee);
    //}
        
        
        @GetMapping("/getAll")
        public ResponseEntity<List<Employee>> getEmployee()
        {
        	logger.info("It gives the information of the employee data");
        	List<Employee>employees=employeeservice.getEmployee();
			return ResponseEntity.status(HttpStatus.OK)
                                 .header("info","data retrieved successfully")
                                 .body(employees);
					         
        }
        
        
          @GetMapping("/{id}")
          public ResponseEntity<Employee>getEmployeebyId(@PathVariable("id") Long id)
          {
        	  logger.debug("It gives about the debugging details");
        	  Employee employee=employeeservice.getEmployeebyId(id);
        			  return ResponseEntity.ok(employee);
          }

          
          
          @DeleteMapping("/{id}")
          public ResponseEntity<Void> deleteById(@PathVariable("id") Long id)
          {
        	  logger.warn("It gives the warning messages");
        	 employeeservice.deleteEmployeeId(id);
        			 return ResponseEntity.noContent().build();
          }

        @PutMapping("/{id}")
          public ResponseEntity<Employee>UpdateEmployee(@PathVariable("id")Long id,@RequestBody  Employee UpdateEmployeeDetails)
          {
        	logger.error("It identifies the error messages");
          	Employee employee=employeeservice.UpdateEmployeeById(id,UpdateEmployeeDetails);
          	return ResponseEntity.status(HttpStatus.OK)
                                   .header("info","data updated successfully")
                                   .body(employee);
          }
        
      @PatchMapping("/{id}")
      public ResponseEntity<Employee>UpdateEmployeeById(@PathVariable("id")Long id,@RequestBody  Map<String,Object>UpdateSpecificDetails)
      {
      	Employee employee=employeeservice.UpdateSpecificEmployeeById(id,UpdateSpecificDetails);
      	return ResponseEntity.status(HttpStatus.OK)
                               .header("info","data updated successfully")
                               .body(employee);
      }
    
       @PostMapping("/bulk")  
       public ResponseEntity<List<Employee>>SaveAllEmployees(@RequestBody @Valid List<Employee>employees)
       {
    	   List<Employee>SavedEmployees=employeeservice.SaveAllEmployees(employees);
    	   return ResponseEntity.status(HttpStatus.CREATED)
                                .header("info","data created successfully")
                                .body(SavedEmployees);
                                
       }             
        @GetMapping("/count")
        public ResponseEntity<Long>getEmployees()
        {
        	Long count=employeeservice.getEmployeecount();
        	return ResponseEntity.status(HttpStatus.OK)
        			             .header("info","retrived data successfully")
        			             .body(count);
        }
        
        @DeleteMapping("/deleteAll")
        public ResponseEntity<Void>deleteEmployees()
        {
        	employeeservice.deleteAllEmployees();
        	return ResponseEntity.noContent().build();
        }
        
        @PostMapping("/save")
        public ResponseEntity<EntityModel<Employee>> SaveEmployee(@RequestBody @Valid Employee employee)
       {
           
   	     Employee SavedEmployee=employeeservice.saveEmployeeData(employee);
   	     EntityModel<Employee>entityModel=EntityModel.of(SavedEmployee);
   	     entityModel.add(linkTo(methodOn(Employeecontroller.class).getEmployeebyId(SavedEmployee.getId())).withSelfRel());
   	     entityModel.add(linkTo(methodOn(Employeecontroller.class).deleteById(SavedEmployee.getId())).withRel("Delete"));
   	     entityModel.add(linkTo(methodOn(Employeecontroller.class).UpdateEmployee(SavedEmployee.getId(),SavedEmployee)).withRel("update"));
   	     entityModel.add(linkTo(methodOn(Employeecontroller.class).UpdateEmployeeById(SavedEmployee.getId(),new HashMap<>())).withRel("Patch"));
   	     return ResponseEntity.status(HttpStatus.CREATED)
   	    	.header("info","data saved successfully")
   	    	.body(entityModel);
       }
         
        @GetMapping("/search1")
        public ResponseEntity<Employee>getEmployeebyEmail(@RequestParam("email") String email)
        {
      	
      	  Employee employee=employeeservice.getEmployeebyEmail(email);
      			  return ResponseEntity.ok(employee);
        }
             
        @GetMapping("/search2")
        public ResponseEntity <List<Employee>> getEmployeebyGender(@RequestParam("gender") String gender)
        {
      	
      	 List<Employee>employees=employeeservice.getEmployeebyGender(gender);
      			  return ResponseEntity.ok(employees);
        }
        
        
        @GetMapping("/search3")
        public ResponseEntity <List<Employee>> getEmployeebyDeptAndGender(@RequestParam("dept") String dept,@RequestParam("gender") String gender)
        {
      	 List<Employee>employees=employeeservice.getEmployeebyDeptAndGender(dept,gender);
      			  return ResponseEntity.ok(employees);
        }
        
        @GetMapping("/search4")
        public ResponseEntity <List<Employee>> getEmployeebySalaryGreaterThan(@RequestParam("minsalary") double minsalary)
        {
      	 List<Employee>employees=employeeservice.getEmployeebySalaryGreaterThan(minsalary);
      			  return ResponseEntity.ok(employees);
        }
        
        @GetMapping("/search5")
        public ResponseEntity <List<Employee>> getEmployeebySalaryBetween(@RequestParam("minsalary") double minsalary,@RequestParam("maxsalary") double maxsalary)
        {
      	 List<Employee>employees=employeeservice.getEmployeebySalaryBetween(minsalary,maxsalary);
      			  return ResponseEntity.ok(employees);
        }
        
        
        
}

