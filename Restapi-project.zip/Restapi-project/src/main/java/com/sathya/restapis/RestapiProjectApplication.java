package com.sathya.restapis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapiProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapiProjectApplication.class, args);
	}

}
