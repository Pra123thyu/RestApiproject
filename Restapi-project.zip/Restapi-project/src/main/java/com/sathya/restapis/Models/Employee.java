package com.sathya.restapis.Models;

import jakarta.annotation.Generated;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Employee {
	   @Id
	   @GeneratedValue(strategy=GenerationType.AUTO)
       private long id;

	    @NotBlank(message = "Name must not be blank")
	    @Size(min = 2, max = 50, message = "Name must be between 2 and 50 characters")
	    private String name;

	    @NotNull(message = "Salary is required")
	    @Positive(message = "Salary must be greater than 0")

	    private Double salary;

	    @NotBlank(message = "Department is required")
	    @Size(max = 30, message = "Department name must not exceed 30 characters")
	    private String dept;

	    @NotBlank(message = "Gender is required")
	    private String gender;

	    @DecimalMin(value = "0.0", inclusive = true, message = "PF must be 0 or greater")
	    private double pf;

	    @DecimalMin(value = "0.0", inclusive = true, message = "Tax must be 0 or greater")
	    private double tax;
	 
	    private String email;

}
